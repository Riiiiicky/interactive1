$(document).ready(function(){
  $("#contact-window").hide();

$("#contacteing").click(function() {
  $("#contact-window").show();
  
 $("#xcontact").click(function() {
  $("#contact-window").hide();
  
});          });          });

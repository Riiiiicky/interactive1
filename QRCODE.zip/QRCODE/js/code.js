$(document).ready(function(){
  $("#content").hide();

$("#pic").click(function() {
  $("#content").show();
  $("#pic").hide();
  
 $("#content").click(function() {
  $("#content").hide();
  $("#pic").show();
  
});          });          });
